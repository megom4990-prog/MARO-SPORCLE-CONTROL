Party Arena Android demo.
Standalone trivia party-game prototype with an integrated in-game control menu.
Current version is a local demo only. True multiplayer across phones needs a backend
for synchronized rooms, players, host privileges, kick actions and chat.
It uses original branding and does not connect to Sporcle Party servers.
Build: Android Studio or GitHub Actions; Gradle assembleDebug.
