Sporcle Party MOD Demo — مشروع Android Studio

هذا مشروع تطبيق Android بسيط يعرض النسخة التجريبية داخل WebView بملء الشاشة.
لا يتصل بخوادم Sporcle Party الأصلية ولا يغيّر اللعبة الأصلية أو صلاحيات لاعبيها.

إنشاء APK:
1) ثبّت Android Studio على الكمبيوتر.
2) افتح Android Studio ثم اختر Open وافتح مجلد SporclePartyMOD_Android.
3) انتظر Gradle Sync. إذا طلب تثبيت Android SDK Platform 35 فوافق.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد APK عادةً داخل app/build/outputs/apk/debug/app-debug.apk.

المتطلبات: Android Studio حديث و Android SDK Platform 35.

بناء APK من الموبايل فقط عبر GitHub Actions:
1) أنشئ حسابًا أو سجّل الدخول في github.com.
2) أنشئ مستودعًا جديدًا (New repository).
3) ارفع محتويات هذا المجلد إلى المستودع مع الحفاظ على المجلد المخفي .github.
4) افتح تبويب Actions ثم اختر Build Android APK ثم Run workflow.
5) بعد نجاح التشغيل، افتح نتيجة التشغيل وانزل إلى Artifacts وحمّل SporclePartyMOD-debug-apk.zip.
6) فك ضغط الملف ثم ثبّت app-debug.apk. قد يطلب Android السماح بالتثبيت من هذا المصدر.

قد تتغير واجهة GitHub على الهاتف. لا تشارك كلمة مرورك أو رموز تسجيل الدخول.
